#include "notepad.h"

NotePad::NotePad(QWidget *parent)
	: QMainWindow(parent), content(), findDialog(nullptr)
{
	text = new QTextEdit(this);
	setCentralWidget(text);
	resize(QSize(800, 600));
	setCurrentFile(QString());
	connect(text, SIGNAL(textChanged()), this, SLOT(textModified()));
	createActions();
	createMenus();
	createToolBars();
}
void NotePad::createActions()
{
	newAction = new QAction(tr("&New"), this);
	newAction->setShortcut(QKeySequence::New);
    newAction->setIcon(QIcon("D:/qt projects/notepad/images/new.png"));
	newAction->setToolTip(tr("Create a new text file."));

	openAction = new QAction(tr("&Open"), this);
	openAction->setShortcut(QKeySequence::Open);
    openAction->setIcon(QIcon("D:/qt projects/notepad/images/open.png"));
	openAction->setToolTip(tr("Open a text file."));

	saveAction = new QAction(tr("&Save"), this);
	saveAction->setShortcut(QKeySequence::Save);
    saveAction->setIcon(QIcon("D:/qt projects/notepad/images/save.png"));
	saveAction->setToolTip(tr("Save the current text file."));

	saveasAction = new QAction(tr("&Save as"), this);
	saveasAction->setShortcut(QKeySequence::SaveAs);

	copyAction = new QAction(tr("&Copy"), this);
	copyAction->setShortcut(QKeySequence::Copy);
    copyAction->setIcon(QIcon("D:/qt projects/notepad/images/copy.png"));

	pasteAction = new QAction(tr("&Paste"), this);
	pasteAction->setShortcut(QKeySequence::Paste);
    pasteAction->setIcon(QIcon("D:/qt projects/notepad/images/paste.png"));

	cutAction = new QAction(tr("&Cut"), this);
	cutAction->setShortcut(QKeySequence::Cut);
    cutAction->setIcon(QIcon("D:/qt projects/notepad/images/cut.png"));

	findAction = new QAction(tr("&Find"), this);
	findAction->setShortcut(QKeySequence::Find);
    findAction->setIcon(QIcon("D:/qt projects/notepad/images/find.png"));

	replaceAction = new QAction(tr("&Replace"), this);
	replaceAction->setShortcut(QKeySequence::Replace);

	connect(newAction, SIGNAL(triggered()), this, SLOT(newFile()));
	connect(openAction, SIGNAL(triggered()), this, SLOT(openFile()));
	connect(saveAction, SIGNAL(triggered()), this, SLOT(saveFile()));
	connect(saveasAction, SIGNAL(triggered()), this, SLOT(saveAs()));

	connect(copyAction, SIGNAL(triggered()), text, SLOT(copy()));
	connect(pasteAction, SIGNAL(triggered()), text, SLOT(paste()));
	connect(cutAction, SIGNAL(triggered()), text, SLOT(cut()));
	connect(findAction, SIGNAL(triggered()), this, SLOT(showFindDialog()));
	connect(replaceAction, SIGNAL(triggered()), this, SLOT(showReplaceDialog()));
}
void NotePad::createMenus()
{
	fileMenu = menuBar()->addMenu(tr("&File"));
	fileMenu->addActions({ newAction,openAction,saveAction,saveasAction });
	editMenu = menuBar()->addMenu(tr("&Edit"));
	editMenu->addActions({ copyAction,pasteAction,cutAction });
	editMenu->addSeparator();
	editMenu->addActions({ findAction,replaceAction });
}
void NotePad::createToolBars()
{
	fileToolBar = addToolBar(tr("&File"));
	fileToolBar->addActions({ newAction,openAction,saveAction });
	editToolBar = addToolBar(tr("&Edit"));
	editToolBar->addActions({ copyAction,pasteAction,cutAction,findAction });
}
bool NotePad::okToContinue()
{
	if (isWindowModified())
	{
		int r = QMessageBox::warning(this, tr("NotePad"), tr("The text has been modified.\n"
			"Do you want to save your changes?"),
			QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
		if (r == QMessageBox::Yes)
			return saveFile();
		else if (r == QMessageBox::Cancel)
			return false;
	}
	return true;
}
void NotePad::setCurrentFile(const QString &fileName)
{
	curFile = fileName;
	QString shownFile = curFile.isEmpty() ? "Untitled" : curFile;
	setWindowModified(false);
	setWindowTitle(tr("%1[*] - %2").arg(shownFile).arg(tr("NotePad")));
}
//Events
void NotePad::closeEvent(QCloseEvent *event)
{
	if (okToContinue())
		event->accept();
	else
		event->ignore();
}
//Slots
bool NotePad::newFile()
{
	if (okToContinue())
	{
		text->clear();
		setCurrentFile(QString());
		return true;
	}
	else
		return false;
}
bool NotePad::openFile()
{
	if (okToContinue())
	{
		QString fileName = QFileDialog::getOpenFileName(this, tr("Open text"), ".", tr("Text files (*.txt)"));
		if (!fileName.isEmpty())
			return open(fileName);
		return false;
	}
	return false;
}
bool NotePad::saveFile()
{
	if (curFile.isEmpty())
		return saveAs();
	return save(curFile);
}
bool NotePad::saveAs()
{
	QString fileName = QFileDialog::getSaveFileName(this, tr("Save text"), ".", tr("Text files (*.txt)"));
	if (!fileName.isEmpty())
		return save(fileName);
	return false;
}
void NotePad::textModified()
{
	setWindowModified(true);
}
bool NotePad::open(const QString &fileName)
{
	QFile file(fileName);
	if (!file.open(QIODevice::ReadOnly))
	{
		QMessageBox::warning(this, tr("NotePad"), tr("Cannot read file %1.\n%2").arg(fileName).arg(file.errorString()));
		return false;
	}
	QTextStream in(&file);
	QString content;
	QApplication::setOverrideCursor(Qt::WaitCursor);
	content = in.readAll();
	text->setPlainText(content);
	setCurrentFile(fileName);
	QApplication::restoreOverrideCursor();
	return true;
}
bool NotePad::save(const QString &fileName)
{
	QFile file(fileName);
	if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
	{
		QMessageBox::warning(this, tr("NotePad"), tr("Cannot save file %1.\n%2").arg(fileName).arg(file.errorString()));
		return false;
	}
	QTextStream out(&file);
	QApplication::setOverrideCursor(Qt::WaitCursor);
	QString content = text->toPlainText();
	for (auto itr = content.cbegin(); itr < content.cend(); itr++)
		if (*itr == '\n')
			out << endl;
		else
			out << *itr;
	setCurrentFile(fileName);
	QApplication::restoreOverrideCursor();
	//out << endl;
	return true;
}
void NotePad::showFindDialog()
{
	if (!findDialog)
	{
		findDialog = new FindDialog(this);
		connect(findDialog, SIGNAL(findPrevious(const QString &, Qt::CaseSensitivity)), this, SLOT(findPrevious(const QString &, Qt::CaseSensitivity)));
		connect(findDialog, SIGNAL(findNext(const QString &, Qt::CaseSensitivity)), this, SLOT(findNext(const QString &, Qt::CaseSensitivity)));
	}
	findDialog->show();
	findDialog->raise();
	findDialog->activateWindow();
}
void NotePad::findPrevious(const QString &str, Qt::CaseSensitivity cs)
{
	QFlags<QTextDocument::FindFlag> flag = (cs == Qt::CaseInsensitive) ? QTextDocument::FindBackward : (QTextDocument::FindBackward | QTextDocument::FindCaseSensitively);
	bool findSucc = text->find(str, flag);
	if (!findSucc)
		QMessageBox::information(this, tr("NotePad"), tr("Can't find \"%1\".").arg(str), QMessageBox::StandardButton::Ok);
}
void NotePad::findNext(const QString &str, Qt::CaseSensitivity cs)
{
	QFlags<QTextDocument::FindFlag> flag = (cs == Qt::CaseInsensitive) ? 0 : QTextDocument::FindCaseSensitively;
	bool findSucc = text->find(str, flag);
	if (!findSucc)
		QMessageBox::information(this, tr("NotePad"), tr("Can't find \"%1\".").arg(str), QMessageBox::StandardButton::Ok);
}
void NotePad::showReplaceDialog()
{
	if (!replaceDialog)
	{
		replaceDialog = new ReplaceDialog(this);
		connect(replaceDialog, SIGNAL(replaceNext(const QString &, const QString &, Qt::CaseSensitivity)), 
			this, SLOT(replaceNext(const QString &, const QString &, Qt::CaseSensitivity, bool)));
		connect(replaceDialog, SIGNAL(replaceAll(const QString &, const QString &, Qt::CaseSensitivity)), 
			this, SLOT(replaceAll(const QString &, const QString &, Qt::CaseSensitivity)));
		connect(replaceDialog, SIGNAL(findNext(const QString &, Qt::CaseSensitivity)), this, SLOT(findNext(const QString &, Qt::CaseSensitivity)));
	}
	replaceDialog->show();
	replaceDialog->raise();
	replaceDialog->activateWindow();
}
bool NotePad::replaceNext(const QString &find, const QString &replace, Qt::CaseSensitivity cs, bool showMsg)
{
	QFlags<QTextDocument::FindFlag> flag = (cs == Qt::CaseInsensitive) ? 0 : QTextDocument::FindCaseSensitively;
	bool findSucc = text->find(find, flag);
	if (!findSucc)
	{
		if(showMsg)
			QMessageBox::information(this, tr("NotePad"), tr("Can't find \"%1\".").arg(find), QMessageBox::StandardButton::Ok);
		return false;
	}
	/*QTextCursor textCursor = text->textCursor();
	textCursor.deleteChar();
	textCursor.insertText(replace);
	text->setTextCursor(textCursor);*/
	text->textCursor().deleteChar();
	text->textCursor().insertText(replace);
	return true;
}
void NotePad::replaceAll(const QString &find, const QString &replace, Qt::CaseSensitivity cs)
{
	QFlags<QTextDocument::FindFlag> flag = (cs == Qt::CaseInsensitive) ? 0 : QTextDocument::FindCaseSensitively;
	text->moveCursor(QTextCursor::Start);
	bool findSucc = text->find(find, flag);
	if (!findSucc)
	{
		QMessageBox::information(this, tr("NotePad"), tr("Can't find \"%1\".").arg(find), QMessageBox::StandardButton::Ok);
		return;
	}
	int count = 0;
	text->moveCursor(QTextCursor::Start);
	while (replaceNext(find, replace, cs, false))
		count++;
	QMessageBox::information(this, tr("NotePad"), tr("%1 text%2 been replaced").arg(count).arg(count == 1 ? " has" : "s have"), QMessageBox::StandardButton::Ok);
}
