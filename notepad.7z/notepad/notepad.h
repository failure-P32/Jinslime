#pragma once
#include <memory>
#include <QtWidgets>
#include "dialogs.h"

class NotePad : public QMainWindow
{
	Q_OBJECT

public:
	NotePad(QWidget *parent = Q_NULLPTR);

private:
	QTextEdit *text;
	QString content;
	QString curFile;

	QAction *newAction;
	QAction *openAction;
	QAction *saveAction;
	QAction *saveasAction;

	QAction *copyAction;
	QAction *pasteAction;
	QAction *cutAction;
	QAction *findAction;
	QAction *replaceAction;

	QMenu *fileMenu;
	QMenu *editMenu;

	QToolBar *fileToolBar;
	QToolBar *editToolBar;

	FindDialog *findDialog;
	ReplaceDialog *replaceDialog;
	
	void createActions();
	void createMenus();
	void createToolBars();
	bool okToContinue();
	void setCurrentFile(const QString &);
	bool open(const QString &);
	bool save(const QString &);

private slots:
	bool newFile();
	bool openFile();
	bool saveFile();
	bool saveAs();
	void textModified();
	void showFindDialog();
	void findPrevious(const QString &, Qt::CaseSensitivity);
	void findNext(const QString &, Qt::CaseSensitivity);
	void showReplaceDialog();
	bool replaceNext(const QString &, const QString &, Qt::CaseSensitivity, bool showMsg = true);
	void replaceAll(const QString &, const QString &, Qt::CaseSensitivity);

protected:
	void closeEvent(QCloseEvent *event) override;
};
